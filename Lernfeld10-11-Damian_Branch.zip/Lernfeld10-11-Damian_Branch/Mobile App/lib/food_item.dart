import 'package:flutter/foundation.dart' show immutable;

const String foodTable = 'foods';

class FoodDatabaseFields {
  // Column Names for Food Tables
  static final List<String> values = [
    id,
    gtin,
    hergestellt,
    hersteller,
    name,
    ablaufdatum,
    kategorie
  ];

  static const id = 'id';
  static const gtin = 'gtin';
  static const hergestellt = 'hergestellt';
  static const hersteller = 'hersteller';
  static const name = 'name';
  static const ablaufdatum = 'ablaufdatum';
  static const kategorie = 'kategorie';

  //TODO die restlichen Hinzufügen!
}

@immutable
class Food {
  final int? id;
  final String? gtin;
  final String? hergestellt; // Selbstgemacht oder Gekauft
  final String? hersteller; // Neuer Wert: Hersteller
  final String? name;
  final DateTime? ablaufdatum;
  final String? kategorie;
  // double? wertPro;
  // double? energie;
  // double? gesamtfettgehalt;
  // double? gesaettigteFettsaeuren;
  // double? kohlenhydrate;
  // double? ballaststoffe;
  // double? eiweiss;
  // double? salz;
  // double? vitaminC;
  // double? vitaminD;
  // double? vitaminA;
  // double? vitaminB1;
  // double? vitaminB2;
  // double? vitaminB3;
  // double? vitaminB5;
  // double? vitaminB6;
  // double? vitaminB7;
  // double? vitaminB11;
  // double? vitaminB12;
  // double? vitaminE;
  // double? vitaminK;
  // double? kalzium;
  // double? eisen;
  // double? arsen;
  // double? bor;
  // double? cholin;
  // double? chlorid;
  // double? chrom;
  // double? kobalt;
  // double? kupfer;
  // double? fluorid;
  // double? fluor;
  // double? jod;
  // double? magnesium;
  // double? mangan;
  // double? molybdaen;
  // double? phosphor;
  // double? kalium;
  // double? rubidium;
  // double? selen;
  // double? silizium;
  // double? schwefel;
  // double? zinn;
  // double? vanadium;
  // double? zink;
  // double? wasser;
  // double? alkohol;

  const Food({
    this.id,
    this.gtin,
    this.hergestellt,
    this.hersteller, // Neuer Wert: Hersteller
    this.name,
    this.ablaufdatum,
    this.kategorie,
    // this.wertPro,
    // this.energie,
    // this.gesamtfettgehalt,
    // this.gesaettigteFettsaeuren,
    // this.kohlenhydrate,
    // this.ballaststoffe,
    // this.eiweiss,
    // this.salz,
    // this.vitaminC,
    // this.vitaminD,
    // this.vitaminA,
    // this.vitaminB1,
    // this.vitaminB2,
    // this.vitaminB3,
    // this.vitaminB5,
    // this.vitaminB6,
    // this.vitaminB7,
    // this.vitaminB11,
    // this.vitaminB12,
    // this.vitaminE,
    // this.vitaminK,
    // this.kalzium,
    // this.eisen,
    // this.arsen,
    // this.bor,
    // this.cholin,
    // this.chlorid,
    // this.chrom,
    // this.kobalt,
    // this.kupfer,
    // this.fluorid,
    // this.fluor,
    // this.jod,
    // this.magnesium,
    // this.mangan,
    // this.molybdaen,
    // this.phosphor,
    // this.kalium,
    // this.rubidium,
    // this.selen,
    // this.silizium,
    // this.schwefel,
    // this.zinn,
    // this.vanadium,
    // this.zink,
    // this.wasser,
    // this.alkohol,
  });

  Food copy({
   int? id,
   String? gtin,
   String? hergestellt, 
   String? hersteller,
   String? name,
   DateTime? ablaufdatum,
   String? kategorie,
  }) =>
        Food(
          id: id ?? this.id,
          gtin: gtin ?? this.gtin,
          hergestellt: hergestellt ?? this.hergestellt,
          hersteller: hergestellt ?? this.hersteller,
          name: name ?? this.name,
          ablaufdatum: ablaufdatum ?? this.ablaufdatum,
          kategorie: kategorie ?? this.kategorie,
        );
    
    Map<String, dynamic> toMap() {
      return <String, dynamic>{
        FoodDatabaseFields.id: id,
        FoodDatabaseFields.gtin: gtin,
        FoodDatabaseFields.hergestellt: hergestellt,
        FoodDatabaseFields.hersteller: hersteller,
        FoodDatabaseFields.name: name,
        FoodDatabaseFields.ablaufdatum: ablaufdatum?.toIso8601String(),
        FoodDatabaseFields.kategorie: kategorie
      };
    }

  // Methode zur Umwandlung von Map in FoodItem
  factory Food.fromMap(Map<String, dynamic> map) {
    return Food(
    id: map[FoodDatabaseFields.id] != null ? map[FoodDatabaseFields.id] as int : null,
    gtin: map[FoodDatabaseFields.gtin] != null ? map[FoodDatabaseFields.gtin] as String : '', // Handle null
    hergestellt: map[FoodDatabaseFields.hergestellt] != null ? map[FoodDatabaseFields.hergestellt] as String : '', // Handle null
    name: map[FoodDatabaseFields.name] != null ? map[FoodDatabaseFields.name] as String : '', // Handle null
    kategorie: map[FoodDatabaseFields.kategorie] != null ? map[FoodDatabaseFields.kategorie] as String : '', // Handle null
    // For other fields, use the same null handling method or provide a sensible default
    // ablaufdatum: DateTime.tryParse(map[FoodDatabaseFields.ablaufdatum] as String? ?? ''),
    // wertPro: map['wertPro'] ?? 0,
      // energie: map['energie'],
      // gesamtfettgehalt: map['gesamtfettgehalt'],
      // gesaettigteFettsaeuren: map['gesaettigteFettsaeuren'],
      // kohlenhydrate: map['kohlenhydrate'],
      // ballaststoffe: map['ballaststoffe'],
      // eiweiss: map['eiweiss'],
      // salz: map['salz'],
      // vitaminC: map['vitaminC'],
      // vitaminD: map['vitaminD'],
      // vitaminA: map['vitaminA'],
      // vitaminB1: map['vitaminB1'],
      // vitaminB2: map['vitaminB2'],
      // vitaminB3: map['vitaminB3'],
      // vitaminB5: map['vitaminB5'],
      // vitaminB6: map['vitaminB6'],
      // vitaminB7: map['vitaminB7'],
      // vitaminB11: map['vitaminB11'],
      // vitaminB12: map['vitaminB12'],
      // vitaminE: map['vitaminE'],
      // vitaminK: map['vitaminK'],
      // kalzium: map['kalzium'],
      // eisen: map['eisen'],
      // arsen: map['arsen'],
      // bor: map['bor'],
      // cholin: map['cholin'],
      // chlorid: map['chlorid'],
      // chrom: map['chrom'],
      // kobalt: map['kobalt'],
      // kupfer: map['kupfer'],
      // fluorid: map['fluorid'],
      // fluor: map['fluor'],
      // jod: map['jod'],
      // magnesium: map['magnesium'],
      // mangan: map['mangan'],
      // molybdaen: map['molybdän'],
      // phosphor: map['phosphor'],
      // kalium: map['kalium'],
      // rubidium: map['rubidium'],
      // selen: map['selen'],
      // silizium: map['silizium'],
      // schwefel: map['schwefel'],
      // zinn: map['zinn'],
      // vanadium: map['vanadium'],
      // zink: map['zink'],
      // wasser: map['wasser'],
      // alkohol: map['alkohol'],
    );
  }

  //  // Methode zur Umwandlung von FoodItem in Map
  // Map<String, dynamic> toMap() {
  //   return {
  //     'id': id,
  //     'gtin': gtin,
  //     'hergestellt': hergestellt,
  //     'hersteller': hersteller,
  //     'name': name,
  //     'ablaufdatum': ablaufdatum?.toIso8601String(),  // Datum als ISO 8601 String
  //     'kategorie': kategorie,
  //     'wertPro': wertPro,
  //     'energie': energie,
  //     'gesamtfettgehalt': gesamtfettgehalt,
  //     'gesaettigteFettsaeuren': gesaettigteFettsaeuren,
  //     'kohlenhydrate': kohlenhydrate,
  //     'ballaststoffe': ballaststoffe,
  //     'eiweiss': eiweiss,
  //     'salz': salz,
  //     'vitaminC': vitaminC,
  //     'vitaminD': vitaminD,
  //     'vitaminA': vitaminA,
  //     'vitaminB1': vitaminB1,
  //     'vitaminB2': vitaminB2,
  //     'vitaminB3': vitaminB3,
  //     'vitaminB5': vitaminB5,
  //     'vitaminB6': vitaminB6,
  //     'vitaminB7': vitaminB7,
  //     'vitaminB11': vitaminB11,
  //     'vitaminB12': vitaminB12,
  //     'vitaminE': vitaminE,
  //     'vitaminK': vitaminK,
  //     'kalzium': kalzium,
  //     'eisen': eisen,
  //     'arsen': arsen,
  //     'bor': bor,
  //     'cholin': cholin,
  //     'chlorid': chlorid,
  //     'chrom': chrom,
  //     'kobalt': kobalt,
  //     'kupfer': kupfer,
  //     'fluorid': fluorid,
  //     'fluor': fluor,
  //     'jod': jod,
  //     'magnesium': magnesium,
  //     'mangan': mangan,
  //     'molybdän': molybdaen,
  //     'phosphor': phosphor,
  //     'kalium': kalium,
  //     'rubidium': rubidium,
  //     'selen': selen,
  //     'silizium': silizium,
  //     'schwefel': schwefel,
  //     'zinn': zinn,
  //     'vanadium': vanadium,
  //     'zink': zink,
  //     'wasser': wasser,
  //     'alkohol': alkohol,
  //   };
  }

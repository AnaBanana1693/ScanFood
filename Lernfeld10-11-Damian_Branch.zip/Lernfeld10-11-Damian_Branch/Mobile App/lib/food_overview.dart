import 'package:flutter/material.dart';
import 'package:smart_food_management/food_list_tile.dart';
import 'food_item.dart'; // Importierung des Modells
import 'package:smart_food_management/database_helper.dart'; // Importierung der Datenbankklasse

class FoodOverview extends StatefulWidget {
  const FoodOverview({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _FoodOverviewState createState() => _FoodOverviewState();
}

class _FoodOverviewState extends State<FoodOverview> {
  	bool isLoading = false;
    List<Food> food = [];

    Future<void> getAllFoodEntries() async {
      setState(() => isLoading = true);

      food = await FoodDatabase.instance.readAllFood();

      setState(() => isLoading = false);
    }

    @override
    void initState() {
      super.initState();
      getAllFoodEntries();
    }

    @override
    void dispose() {
      // FoodDatabase.instance.close();
      super.dispose();
    }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lebensmittel Übersicht'),
        backgroundColor: Colors.green,
      ),
      body: isLoading ? const Center(child: CircularProgressIndicator()): _buildFoodList(),
    );
  }

  Widget _buildFoodList() {
    return ListView.builder(
      itemCount: food.length,
      itemBuilder: (context, index) {
        final foods = food[index];

      return FoodListTile(food: foods);
      },
    );
  }
}

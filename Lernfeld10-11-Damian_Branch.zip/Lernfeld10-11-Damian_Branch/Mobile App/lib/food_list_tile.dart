import 'package:flutter/cupertino.dart';
import 'package:smart_food_management/food_item.dart';

class FoodListTile extends StatelessWidget {
  const FoodListTile({super.key, required this.food});

  final Food food;

  @override
  Widget build(BuildContext context) {
    return CupertinoListTile(
      title: Text(
        food.name ?? '',
      ),
    );
  }
}
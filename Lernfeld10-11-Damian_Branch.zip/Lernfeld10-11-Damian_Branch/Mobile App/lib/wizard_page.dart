import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:smart_food_management/food_item.dart';
import 'package:smart_food_management/database_helper.dart';

class FoodItemWizard extends StatefulWidget {
  const FoodItemWizard({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _FoodItemWizardState createState() => _FoodItemWizardState();
}

class _FoodItemWizardState extends State<FoodItemWizard> {
  final _pageController = PageController();
  final _formKey = GlobalKey<FormState>();

  String? _hergestellt;
  String? _name;
  String? _kategorie;
  final Map<String, dynamic> _naehrwerte = {};

  final _gtinController = TextEditingController();
  final _nameController = TextEditingController();
  final _kategorieController = TextEditingController(); // Für Dropdowns nicht nötig, aber zur Veranschaulichung
  final _energieController = TextEditingController(); 
  //TODO Weitere Controller für die Nährwerte hinzufügen.

  @override
  void dispose() {
    _gtinController.dispose();
    _nameController.dispose();
    _kategorieController.dispose();
    _energieController.dispose(); // Dispose andere Controller ebenfalls
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lebensmittel hinzufügen'),
        backgroundColor: Colors.green,
      ),
      body: PageView(
        controller: _pageController,
        children: [
          _buildHerstellungPage(),
          if (_hergestellt == 'Gekauft') _buildGtinPage(),
          _buildNamePage(),
          _buildKategoriePage(),
          _buildNaehrwertePage(),
          _buildSavePage(),
        ],
      ),
    );
  }

  Widget _buildHerstellungPage() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('Ist das Lebensmittel selbstgemacht oder gekauft?'),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _hergestellt = 'Selbstgemacht';
                FocusScope.of(context).unfocus(); // Tastatur ausblenden
                _pageController.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              });
            },
            child: const Text('Selbstgemacht'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _hergestellt = 'Gekauft';
                FocusScope.of(context).unfocus(); // Tastatur ausblenden
                _pageController.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              });
            },
            child: const Text('Gekauft'),
          ),
        ],
      ),
    );
  }

  Widget _buildGtinPage() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('Bitte geben Sie die GTIN ein:'),
              TextFormField(
                controller: _gtinController,
                decoration: const InputDecoration(labelText: 'GTIN'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Bitte geben Sie die GTIN ein';
                  }
                  return null;
                },
              ),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState?.validate() ?? false) {
                    FocusScope.of(context).unfocus(); // Tastatur ausblenden
                    _pageController.nextPage(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                    );
                  }
                },
                child: const Text('Weiter'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNamePage() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('Bitte geben Sie den Namen des Lebensmittels ein:'),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: 'Name'),
                keyboardType: TextInputType.text,
              ),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState?.validate() ?? false) {
                    FocusScope.of(context).unfocus(); // Tastatur ausblenden
                    _pageController.nextPage(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                    );
                  }
                },
                child: const Text('Weiter'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildKategoriePage() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Bitte wählen Sie eine Kategorie aus:'),
            DropdownButton<String>(
              value: _kategorie,
              hint: const Text('Kategorie wählen'),
              items: <String>[
                'Getreideprodukte', 'Babynahrung', 'Backzutaten', 'Brot', 
                'Fast Food', 'Fisch', 'Fleisch', 'Geflügel', 'Gemüse', 
                'Getränke (Alkoholfrei)', 'Getränke (alkoholisch)', 'Hülsenfrüchte',
                'Milch & Milcherzeugnisse', 'Nüsse', 'Obst', 'Schokolade', 
                'Süßwaren', 'Öle', 'Verschiedenes'
              ].map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _kategorie = value;
                });
              },
            ),
            ElevatedButton(
              onPressed: () {
                FocusScope.of(context).unfocus(); // Tastatur ausblenden
                _pageController.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              },
              child: const Text('Weiter'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNaehrwertePage() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Bitte geben Sie die Nährwertangaben ein:'),
            TextFormField(
              controller: _energieController,
              decoration: const InputDecoration(labelText: 'Energie (kcal)'),
              keyboardType: TextInputType.number,
              onChanged: (value) {
                _naehrwerte['energie'] = double.tryParse(value);
              },
            ),
            // Fügen Sie hier die anderen Nährwertangaben hinzu...
            ElevatedButton(
              onPressed: () {
                FocusScope.of(context).unfocus(); // Tastatur ausblenden
                _pageController.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              },
              child: const Text('Weiter'),
            ),
          ],
        ),
      ),
    );
  }

// Add Food everytime "Alles bereit zum Speichern" - Button is clicked.
  Future<void> addFood() async {
    final food = Food(
      gtin: _gtinController.text,
      hergestellt: _hergestellt,
      name: _nameController.text,
       //TODO noch im Prozess mit einbinden!!!

                  // wertPro: double.tryParse(_wertProController.text),
                  // energie: double.tryParse(_energieController.text),
                  // gesamtfettgehalt: double.tryParse(_gesamtfettgehaltController.text),
                  // gesaettigteFettsaeuren: double.tryParse(_gesaettigteFettsaeurenController.text),
                  // kohlenhydrate: double.tryParse(_kohlenhydrateController.text),
                  // ballaststoffe: double.tryParse(_ballaststoffeController.text),
                  // eiweiss: double.tryParse(_eiweissController.text),
                  // salz: double.tryParse(_salzController.text),
                  // vitaminC: double.tryParse(_vitaminCController.text),
                  // vitaminD: double.tryParse(_vitaminDController.text),
                  // vitaminA: double.tryParse(_vitaminAController.text),
                  // vitaminB1: double.tryParse(_vitaminB1Controller.text),
                  // vitaminB2: double.tryParse(_vitaminB2Controller.text),
                  // vitaminB3: double.tryParse(_vitaminB3Controller.text),
                  // vitaminB5: double.tryParse(_vitaminB5Controller.text),
    );

    await FoodDatabase.instance.createFoodEntries(food);
  }

   Widget _buildSavePage() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Alles bereit zum Speichern!'),
            ElevatedButton(
              onPressed: () {
                addFood();
                Navigator.pushNamed(context, '/LebensmittelHinzufuegenPage');
              },
              child: const Text('Speichern'),
            ),
          ],
        ),
      ),
    );
  }
}

import 'dart:async';
import 'package:flutter/foundation.dart' show immutable;
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'food_item.dart'; // Das Modell importieren

@immutable
class FoodDatabase {
  static const String _databaseName = 'food_database.db';
  static const int _databaseVersion = 1;

  const FoodDatabase._privateConstructor();
  static const FoodDatabase instance = FoodDatabase._privateConstructor();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String dbPath = await getDatabasesPath();
    final String path = join(dbPath, _databaseName);
    return await openDatabase(
    path,
    version: _databaseVersion,
    onCreate: _createDB,
    );
  }

//! Create Database method
  Future _createDB(
    Database db,
    int version
  ) async {
    const idType = 'INTEGER PRIMARY KEY AUTOINCREMENT';
    const gtinType = 'TEXT';
    const hergestelltType = 'TEXT';
    const herstellerType = 'TEXT';
    const kategorieType = 'TEXT';
    const ablaufdatumType = 'TEXT';
    const nameType = 'TEXT';

    await db.execute('''
      CREATE TABLE IF NOT EXISTS $foodTable (
      ${FoodDatabaseFields.id} $idType,
      ${FoodDatabaseFields.gtin} $gtinType,
      ${FoodDatabaseFields.hergestellt} $hergestelltType,
      ${FoodDatabaseFields.hersteller} $herstellerType,
      ${FoodDatabaseFields.kategorie} $kategorieType,
      ${FoodDatabaseFields.ablaufdatum} $ablaufdatumType,
      ${FoodDatabaseFields.name} $nameType
    )
  ''');
  }

  //! C --> CRUD = CREATE
  Future<Food> createFoodEntries(Food food) async {
    final db = await instance.database;
    final id = await db.insert(
      foodTable, 
      food.toMap()
    );
  
  return food.copy(id: id);
  }

//! R --> CRUD = READ
  Future<Food> readFood(int id) async {
    final db = await instance.database;
    
    final foodData = await db.query(
      foodTable,
      columns: FoodDatabaseFields.values,
      where: '${FoodDatabaseFields.id} = ?',
      whereArgs: [id],
    );

    if (foodData.isNotEmpty) {
      return Food.fromMap(foodData.first);
    } else {
      throw Exception('Es wurde kein Datensatz mit der gegebenen ID gefunden.');
    }
  }

  // Get All Foods
  Future<List<Food>> readAllFood() async {
    final db = await instance.database;

    final result = 
          await db.query(foodTable, orderBy: '${FoodDatabaseFields.ablaufdatum} ASC');

    return result.map((foodData) => Food.fromMap(foodData)).toList();
  }

  //! U --> CRUD = Update
  Future<int> updateFood(Food food) async {
    final db = await instance.database;

    return await db.update(
      foodTable,
      food.toMap(),
      where: '${FoodDatabaseFields.id} = ?',
      whereArgs: [food.id], 
    );
  }

  //! D --> CRUD = DELETE
  Future<int> deleteFood(int id) async {
    final db = await instance.database;

    return await db.delete(
      foodTable,
      where: '${FoodDatabaseFields.id} = ?',
      whereArgs: [id],
    );
  }

  Future close() async {
    final db = await instance.database;
     db.close();
  }
}
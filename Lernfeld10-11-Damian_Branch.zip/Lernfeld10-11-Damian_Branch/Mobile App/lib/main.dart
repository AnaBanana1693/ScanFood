import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:smart_food_management/database_helper.dart';
import 'package:smart_food_management/wizard_page.dart';
import 'package:smart_food_management/food_overview.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await FoodDatabase.instance.database;

  runApp(const MyApp());

  WidgetsBinding.instance.addObserver(_LifeCycleEventHandler(
    detachedCallBack: () async => await FoodDatabase.instance.close(),
  ));
}

class _LifeCycleEventHandler extends WidgetsBindingObserver {
  final AsyncCallback ? detachedCallBack;

  _LifeCycleEventHandler({this.detachedCallBack});

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.detached) {
      detachedCallBack?.call();
    }
  }
}


class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SmartFood Management',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.green, // Primärfarbe passend zum Thema Nachhaltigkeit
        colorScheme: ColorScheme.fromSwatch().copyWith(
          secondary: Colors.orange, // Akzentfarbe für interaktive Elemente
        ),
      ),
      home: const HomePage(),
      routes: {
        '/LebensmittelHinzufuegenPage': (context) => const LebensmittelHinzufuegenPage(),
      },
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SmartFood Management'), // Titel der App in der Navigation Bar
        titleTextStyle: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        backgroundColor: Colors.green, // Hintergrundfarbe der Navigation Bar
        iconTheme: const IconThemeData(
          color: Colors.white, // Setzt die Farbe des Burger-Menüs auf Weiß
        ),
      ),
      drawer: Drawer( // Drawer-Menü nur auf der linken Seite
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.green, // Hintergrundfarbe des Headers passend zum Thema
              ),
              child: Text(
                'Navigation',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.calendar_today),
              title: const Text('Kalender für ablaufende Lebensmittel'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const KalenderPage()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.add_box),
              title: const Text('Lebensmittel hinzufügen'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const LebensmittelHinzufuegenPage()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.restaurant_menu),
              title: const Text('Rezeptvorschläge'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const RezeptVorschlaegePage()),
                );
              },
            ),
          ],
        ),
      ),
      body: const Center(
        child: Text(
          'Willkommen zu SmartFood Management!',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}

// Dummy-Seite für den Kalender
class KalenderPage extends StatelessWidget {
  const KalenderPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kalender für ablaufende Lebensmittel'),
        titleTextStyle: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        backgroundColor: Colors.green, // Hintergrundfarbe der Navigation Bar
        iconTheme: const IconThemeData(
          color: Colors.white, // Setzt die Farbe des Burger-Menüs auf Weiß
        ),
      ),
      body: const Center(
        child: Text('Hier ist der Kalender für ablaufende Lebensmittel.'),
      ),
    );
  }
}

// Seite für Lebensmittel hinzufügen mit drei Balken
class LebensmittelHinzufuegenPage extends StatelessWidget {
  const LebensmittelHinzufuegenPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lebensmittel hinzufügen'),
        titleTextStyle: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        backgroundColor: Colors.green, // Hintergrundfarbe der Navigation Bar
        iconTheme: const IconThemeData(
          color: Colors.white, // Setzt die Farbe des Burger-Menüs auf Weiß
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            ElevatedButton(
              onPressed: () {
                 Navigator.push(context, MaterialPageRoute(builder: (context) => const FoodOverview()));
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                backgroundColor: Colors.green, // Hintergrundfarbe des Buttons
              ),
              child: const Text(
                'Alle Lebensmittel anzeigen',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
            ),
            const SizedBox(height: 20), // Abstand zwischen den Balken
            ElevatedButton(
              onPressed: () {
                // Logik zum manuellen Hinzufügen von Lebensmitteln
                Navigator.push(context, MaterialPageRoute(builder: (context) => const FoodItemWizard()));
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                backgroundColor: Colors.green, // Hintergrundfarbe des Buttons
              ),
              child: const Text(
                'Manuell Hinzufügen',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
            ),
            const SizedBox(height: 20), // Abstand zwischen den Balken
            ElevatedButton(
              onPressed: () {
                // Logik zum Hinzufügen von Lebensmitteln über Scanner (später hinzuzufügen)
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                backgroundColor: Colors.green, // Hintergrundfarbe des Buttons
              ),
              child: const Text(
                'Über Scanner hinzufügen',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Dummy-Seite für Rezeptvorschläge
class RezeptVorschlaegePage extends StatelessWidget {
  const RezeptVorschlaegePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rezeptvorschläge'),
        titleTextStyle: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        backgroundColor: Colors.green, // Hintergrundfarbe der Navigation Bar
        iconTheme: const IconThemeData(
          color: Colors.white, // Setzt die Farbe des Burger-Menüs auf Weiß
        ),
      ),
      body: const Center(
        child: Text('Hier sind die Rezeptvorschläge.'),
      ),
    );
  }
}
